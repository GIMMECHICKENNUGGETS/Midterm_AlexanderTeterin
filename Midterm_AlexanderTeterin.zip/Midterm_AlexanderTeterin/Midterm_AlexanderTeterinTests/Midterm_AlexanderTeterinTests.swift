//
//  Midterm_AlexanderTeterinTests.swift
//  Midterm_AlexanderTeterinTests
//
//  Created by Alex T on 10/18/25.
//

import Testing
@testable import Midterm_AlexanderTeterin

struct Midterm_AlexanderTeterinTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
