//  Midterm
//  Alexander Teterin
//  10/18/25

import Foundation
import SwiftUI

struct Subject: Codable {
    var name: String
    var imageName: String
    var description: String
    var year: String
}
