//  Midterm
//  Alexander Teterin
//  10/18/25

import SwiftUI

let subjectData: [Subject] = load("Data.json")

struct ContentView: View {
    
    var body: some View {
        NavigationStack {
            // Updated List to use the 'name' property as the unique identifier
            List(subjectData, id: \.name) { car in
                NavigationLink(destination: DetailView(subject: car)) {
                    HStack {
                        Image(car.imageName)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.gray, lineWidth: 1))
                        
                        Text(car.name)
                            .font(.headline)
                    }
                }
            }
            .navigationTitle("Alex's Classic Car Collection")
        }
    }
}

struct DetailView: View {
    let subject: Subject
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 15) {
                
                Image(subject.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                    .shadow(radius: 10)
                
                Text(subject.name)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("Year: \(subject.year)")
                    .font(.title3)
                    .foregroundColor(.secondary)
                
                Divider()
                
                Text("Description")
                    .font(.title2)
                    .fontWeight(.semibold)
                
                Text(subject.description)
                    .font(.body)
                    .lineSpacing(5)
            }
            .padding()
        }
        .navigationTitle(subject.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
