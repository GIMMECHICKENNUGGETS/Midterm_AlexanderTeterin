//  Midterm
//  Alexander Teterin
//  10/18/25

import SwiftUI

@main
struct Midterm_AlexanderTeterinApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
